
using System.Diagnostics.CodeAnalysis;

[assembly: SuppressMessage("Microsoft.Design", "CA1020:AvoidNamespacesWithFewTypes", Scope = "namespace", Target = "VB.Common.Core.Utilities", Justification = "This namespace is expected to grow to many times its current size")]
