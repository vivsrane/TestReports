namespace VB.Common.Core.Xml
{
    public interface IRenderXml
    {
        string AsXml();
    }
}