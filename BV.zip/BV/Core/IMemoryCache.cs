﻿namespace VB.Common.Core
{
    // Same as ICache, but guaranteed to be in memory.
    public interface IMemoryCache : ICache
    {
    }
}