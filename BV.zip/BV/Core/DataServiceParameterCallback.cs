namespace VB.Common.Core
{
    public delegate object DataServiceParameterCallback(string parameterName);
}