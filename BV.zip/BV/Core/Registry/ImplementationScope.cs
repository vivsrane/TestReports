namespace VB.Common.Core.Registry
{
    public enum ImplementationScope
    {
        Isolated,
        Shared
    }
}