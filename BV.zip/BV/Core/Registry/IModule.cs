namespace VB.Common.Core.Registry
{
    public interface IModule
    {
        void Configure(IRegistry registry);
    }
}
