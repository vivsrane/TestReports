using System;

namespace VB.Common.Core.Memento
{
    public interface IMemento<TEntity> : IEquatable<TEntity>
    {
    }
}