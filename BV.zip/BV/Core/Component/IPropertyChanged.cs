﻿namespace VB.Common.Core.Component
{
    public interface IPropertyChanged
    {
        void OnUnknownPropertyChanged();
    }
}