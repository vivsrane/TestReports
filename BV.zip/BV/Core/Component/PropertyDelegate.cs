﻿namespace VB.Common.Core.Component
{
    public delegate TProperty PropertyDelegate<TClass,TProperty>(TClass value);
}