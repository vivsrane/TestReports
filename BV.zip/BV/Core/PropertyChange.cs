namespace VB.Common.Core
{
    public delegate void PropertyChange();
}