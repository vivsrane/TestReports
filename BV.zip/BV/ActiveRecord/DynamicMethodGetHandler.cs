namespace VB.Common.ActiveRecord
{
    public delegate object DynamicMethodGetHandler(object source);
}