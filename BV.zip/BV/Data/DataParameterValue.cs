namespace VB.Common.Data
{
    public delegate object DataParameterValue(IDataParameterTemplate template);
}