namespace VB.Reports.App.ReportDefinitionLibrary
{
    public enum ReportParameterInputType
    {
        Text,
        Checkbox,
        Radio,
        Password,
        Hidden,
        Select,
    }
}
