namespace VB.Reports.App.ReportDefinitionLibrary
{
    public delegate ReportDataCommandType ResolveDataSourceType(string dataSourceName);
}