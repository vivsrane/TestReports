namespace VB.Reports.App.ReportDefinitionLibrary
{
    public enum ReportContentType
    {
        Excel,
        Pdf,
    }
}
