namespace VB.Reports.App.ReportDefinitionLibrary
{
    public delegate object ResolveParameterValue(string parameterName);
}