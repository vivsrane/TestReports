namespace VB.Reports.App.ReportDefinitionLibrary
{
    public enum ReportTreeNodeType
    {
        ReportGroup,
        ReportHandle,
    }
}
