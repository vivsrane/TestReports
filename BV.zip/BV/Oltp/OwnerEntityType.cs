using System;

namespace VB.DomainModel.Oltp
{
    [Serializable]
    public enum OwnerEntityType
    {
        NotDefined,
        Dealer,
        Seller
    }
}