namespace Csla.Core
{
  /// <summary>
  /// This is the core interface implemented
  /// by all CSLA .NET base classes.
  /// </summary>
  public interface IBusinessObject
  {
  }
}
