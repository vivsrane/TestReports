
using System.Diagnostics.CodeAnalysis;

[assembly: SuppressMessage("Microsoft.Naming", "CA1704:IdentifiersShouldBeSpelledCorrectly", Scope = "namespace", Target = "VB.Common.Pool.Spi", MessageId = "Spi", Justification = "Rename disproportionate to benefit.")]
